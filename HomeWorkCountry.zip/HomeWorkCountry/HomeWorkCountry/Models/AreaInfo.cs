﻿namespace HomeWorkCountry.Models
{
    public class AreaInfo
    {
        public string Region { get; set; }
        public string Timezones { get; set; }
    }
}
